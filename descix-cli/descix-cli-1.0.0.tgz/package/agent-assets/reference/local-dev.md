# Local Development Architecture: The "Local Mesh" Proxy

## 1. Overview

This document outlines the unified architecture for local development of DeSciX Apps (CodeSites and Microservices). The core design principle is to treat the local development environment as a **Local Load Balancer** that mirrors the production routing topology.

**Important**: This document applies to **git-mode** developers who use the CLI for app development. For **drive-mode** users (non-developers using the PWA), app management is handled entirely through the web interface with server-side processing.

This approach unifies three distinct scenarios:
1.  **Platform Dev**: Developing the core platform (PWA + API) locally.
2.  **End-User Dev**: Developing a single App against the production platform.
3.  **Production**: Running live on `*.descix.net`.

## 1.1. Git Mode vs Drive Mode

| Aspect | Git Mode (CLI) | Drive Mode (PWA) |
|--------|---------------|-----------------|
| **User Type** | Developers | Non-technical users |
| **Content Source** | Local git repo (after initial pull from Drive) | Google Drive |
| **Version Control** | Git | Drive/GCS/Firestore |
| **KB Processing** | Local chunking via `kb build/sync` | Server-side pipeline |
| **Configuration** | `workspace.json` | N/A (PWA handles) |
| **Tools** | CLI, VSCode, Git | PWA only |

## 2. The Canonical Routing Model

Instead of exposing implementation details (like GCS bucket URLs or specific port numbers) to the client, the platform uses **Canonical Paths** for all resources.

### 2.1. Route Patterns

| Resource Type | Canonical Path | Production Target (LB) | Local Target (Gateway Proxy) |
| :--- | :--- | :--- | :--- |
| **Core API** | `/apifront`, `/api`, `/mcp` | Core API | `https://localhost:4000` |
| **Powch PWA** | `/powch` | Powch PWA | `https://localhost:5174` |
| **Microservice** | `/s/{community}/{appId}` | k8s-service | `http://localhost:{service.port}` |
| **CodeSite / App Site** | `/Community/{c}/Apps/{a}/site`, `/s/{appId}` | GCS / service | `http://localhost:{site.port}` |
| **PWA** | `/*` | PWA bucket | Served from gateway root (when run from DeSciX_PWA) |

## 3. The "Local Mesh" Proxy

The `descix serve` command spins up a **Local Gateway** on port `5173`. This gateway acts as the router, serving the PWA (when run from `DeSciX_PWA`) and proxying traffic based on the **Workspace Configuration**. Run `npm run dev:serve` from `DeSciX_PWA` or `npx descix serve` with PWA as cwd for Platform Dev.

### 3.1. Configuration: `.descix/workspace.json`
The `workspace.json` file is the **single source of truth** for local routing and app configuration. This is the only configuration methodology - `.descix.app/context.json` files are no longer used.

**Key Features:**
- Workspace root detection (searches upward for `.descix/`, `.cursor/`, or `.vscode/`)
- App context autodiscovery (CLI commands auto-detect community/app from cwd)
- Port registration for local dev servers
- Drive folder configuration for `kb pull/push`

```json
{
  "communities": {
    "descix": {
      "apps": {
        "appsdk": {
          "localPath": "descix/appsdk",
          "kbId": "General",
          "absolutePath": "/path/to/workspace/descix/appsdk",
          "site": {
            "port": 3000,
            "devCommand": "npm run docs:dev"
          },
          "service": {
            "port": 4001,
            "devCommand": "npm run start"
          }
        }
      }
    }
  },
  "driveConfig": {
    "base_folder_id": "...",
    "base_folder_name": "..."
  }
}
```

### 3.2. Proxy Logic (createViteProxyConfig)
The gateway uses `createViteProxyConfig` from `@descix/app-sdk/dev` to generate Vite proxy rules from `workspace.json`:

- **`/apifront`, `/api`, `/mcp`** → `env.apiUrl` or `https://localhost:4000`
- **`/powch`** → `env.powchUrl` or Powch PWA port from `communities.descix.apps.powch.pwa.port`
- **`/s/{community}/{appId}`** → `localhost:{service.port}` for each app in `workspace.json`
- **`/Community/{c}/Apps/{a}/site`** → `localhost:{site.port}` for local app dev
- **`/Community`** → GCS fallback
- **`/.proxy/gcs_media`** → GCS media proxy

## 4. Scenarios

### Scenario 1: Platform Dev ("Dogfooding")
*   **User**: Core Team.
*   **Setup**: Full repo checkout. Run `npm run dev:serve` from `DeSciX_PWA` plus Core, Powch PWA, Powch service. `workspace.json` maps Powch and apps to local ports.
*   **Result**: The gateway serves the PWA at `/` and routes `/apifront` to Core, `/powch` to Powch PWA, `/s/*` to microservices. Local app sites are proxied via `/Community/{c}/Apps/{a}/site`.

### Scenario 2: End-User Dev (Hybrid)
*   **User**: App Developer.
*   **Setup**: `descix init` creates a `workspace.json` mapping *only* their specific app.
*   **Result**:
    *   `/apps/my-community/my-app` -> **Localhost** (User's Dev Server).
    *   `/apps/other-app` -> **Production** (Live GCS).
    *   `/api/core` -> **Production** (Live API).
    *   `/*` (PWA Shell) -> **Production** (Live PWA).

### Scenario 3: Production
*   **User**: End User.
*   **Setup**: No Local Proxy.
*   **Result**: Traffic hits the Cloud Load Balancer, which applies the same routing rules to direct traffic to GCS buckets and Kubernetes services.

## 5. Client-Side Implications

*   **"Dumb" Client**: The PWA Client (`AppData.js`) no longer needs complex logic to rewrite GCS URLs. It simply constructs the canonical path: `/apps/{community}/{app_id}/index.html`.
*   **Embedded Mode**: For embedded scenarios (e.g., iframes), we may retain some legacy rewrite logic as a fallback, but the primary development flow relies on the Proxy.
